Building Exostrap
===================

This is basic documentation on how to build Exostrap from source, with commands.

Getting the source
------------------

Exostrap depends on four upstream Git submodules (``libs/FluentAvalonia``, ``libs/ColorPicker``,
``libs/LucideAvalonia`` and ``backend/virtualdisplay``). A plain "Download ZIP" archive does **not**
include them, so those folders will be empty and the build will fail. Clone with submodules instead:

.. code-block:: bash

   git clone --recurse-submodules https://github.com/YOUR-GITHUB-USERNAME/Exostrap.git

or, in an existing checkout:

.. code-block:: bash

   git submodule update --init --recursive

Dependencies
------------

This wont be is accurate to what is needed to be installed for it to build succesfully,
but more so the acknowlegable ones.

It is way easier if you are on macOS or Linux to just use Nix, and enter the flake devshell with

.. code-block:: bash

   nix develop

and if you get prompted to trust nix configuraiton stuff, you can deny if you don't feel it's safe.

The default shell includes the .NET SDK, Rust toolchain, publishing tools, and lint tools.
For a leaner shell without the extras:

.. code-block:: bash

   nix develop .#minimal  # .NET + Rust only
   nix develop .#dotnet   # .NET only
   nix develop .#rust     # Rust only
   nix develop .#extra    # vpk, avdt, cargo-bloat, and nfpm
   nix develop .#lint     # reuse and typos
   nix develop .#lsp      # .NET + OmniSharp

macOS Specific
~~~~~~~~~~~~~~

- Xcode Command Line Tools

Linux Specific
~~~~~~~~~~~~~~

- dbus (libdbus-1-3)
- icu (libicu-dev)

All other dependents
~~~~~~~~~~~~~~~~~~~~

- Velopack dotnet tool for installers
- Rust compiler (Rust 2024, and preferrably though rustup)
- .NET 10 SDK (Need a C# compiller)
- Git (needed by ``xtask`` to publish with a version, will fault without Git with any command)

Commands
--------

Publish
~~~~~~~

Publishing is going to create installers, and other important stuff making it publishable online.

The default Nix devshell includes ``vpk``; if you use ``.#minimal``, switch to the default shell for installers.

.. code-block:: bash

   cargo xtask publish

and to publish without the installers- e.g packaging for your own system which doesn't need them

.. code-block:: bash

   cargo xtask publish --no-installers

Cross-compiling
~~~~~~~~~~~~~~~

``publish`` and ``compile`` take an ``--override-arch`` flag (``x64`` or ``arm64``) which
forces the entire build to target that architecture instead of the hosts one- so dotnet
gets the matching runtime identifier, the rust backend gets built for the matching target
triple, and the Xcode macOS app is built with the matching ``ARCHS``.

.. code-block:: bash

   cargo xtask publish --override-arch x64

This is how the Intel package is produced from an Apple Silicon machine, and vice versa.

Build
~~~~~

Going to be useful for debug builds, and there's mulitple ways to do so.

.. code-block:: bash

   cargo xtask build

.. code-block:: bash

   dotnet build

Clean
~~~~~

Cleaning out stale stuff- should run both of these.

.. code-block:: bash

   cargo xtask clean

.. code-block:: bash

   dotnet clean

Directories
-----------

Most likely your at this section to figure out where the build stuff goes-
and that is ``/.build``.

- ``.build/publish`` - a publish artifact dir where from ``dotnet publish`` everything useful gets put into
- ``.build/build`` - a directory for non-publish builds
- ``.build/dist`` - a directory for all things that can be distributed (macOS does have .app in there though, which is never signed)
