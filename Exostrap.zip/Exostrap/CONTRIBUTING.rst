Contributing to Exostrap
========================

Thanks for your interest in contributing to Exostrap!

Before opening a pull request
-----------------------------

- Spell check (the ``typos`` CLI is handy)
- Licensing check (the ``reuse`` CLI is handy). Keep the existing SPDX headers in files you edit;
  new files should carry ``SPDX-License-Identifier: MPL-2.0``
- Format your changes (``cargo fmt``, ``nix fmt`` and ``dotnet format``)
- Make sure the change does not introduce new warnings or errors, and does not get in the way of other
  features

Opening an issue
----------------

- Fill in the template accurately, including your Exostrap version and OS
- Search existing issues first, and reopen/comment on a matching one instead of filing a duplicate
- For bugs that also exist in upstream Froststrap, it can help to mention that in the report

Upstream
--------

Exostrap is derived from Froststrap (itself derived from Fishstrap and Bloxstrap). Fixes that apply to the
shared code are welcome upstream too. See ``CREDITS.md``.
