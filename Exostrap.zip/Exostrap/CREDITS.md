# Credits

Exostrap is a fork of **[Froststrap](https://github.com/Froststrap/Froststrap)** (MPL-2.0), which is
itself derived from **[Fishstrap](https://github.com/fishstrap/fishstrap)** and
**[Bloxstrap](https://github.com/bloxstraplabs/bloxstrap)** (MIT). The vast majority of the code is their
work and the work of their contributors; Exostrap changes the branding, packaging identity and
update/Discord configuration (see the README).

Exostrap is not affiliated with or endorsed by Froststrap, Fishstrap, Bloxstrap, or Roblox Corporation.

## What is still provided by upstream Froststrap

Exostrap fetches these from Froststrap's public repositories at runtime:

| Component | Used for |
|-----------|----------|
| `Froststrap/config` (`Data.json` + `.sig`) | Roblox FastFlag allowlist, banned Roblox version hashes, package maps, community mods. Verified with an Ed25519 public key in `RemoteData.cs`. |
| `Froststrap/mod-generator` releases | Cursor / font / emoji mod generation |
| `Froststrap/FroststrapStudioRPC` releases | Roblox Studio Discord presence plugin |

and builds against these submodules: `FluentAvalonia`, `ColorPicker`, `LucideAvalonia`, `virtualdisplay`.

## Licensing

- Source files keep their original `SPDX-FileCopyrightText: 2026 Froststrap` headers; see `LICENSE`
  (MPL-2.0) and the `LICENSES/` directory.
- The Exostrap logo and icons are artwork supplied by the project owner. They are not taken from
  Froststrap, Fishstrap or Bloxstrap.
