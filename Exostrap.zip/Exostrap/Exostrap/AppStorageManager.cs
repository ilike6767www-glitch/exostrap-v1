﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using System.Text.Encodings.Web;
using Exostrap.Enums.AppStoragePresets;
using System.Text.Json.Nodes;

namespace Exostrap
{
    internal static class AppStorageManager
    {
        public static string FileLocation =>
            OperatingSystem.IsLinux()
                ? Path.Combine(Paths.SoberData, "appData", "LocalStorage", "appStorage.json")
                : Path.Combine(Paths.Roblox, "LocalStorage", "appStorage.json");

        private static readonly JsonSerializerOptions SerializerOptions = new()
        {
            // default encoder inflates file by like 30% so we're not gonna use it lol
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
            TypeInfoResolver = JsonHelper.Resolver
        };

        public static void Apply()
        {
            bool background = App.Settings.Prop.EnableRobloxBackgroundApp;

            Mutate(storage =>
            {
                ApplyBackgroundApp(storage, background);
                ApplyTheme(storage);
            });

            // clear registry
            if (!background && OperatingSystem.IsWindows())
                WindowsRegistry.RemoveRobloxStartupEntry();
        }

        private static void ApplyBackgroundApp(JsonObject storage, bool enabled)
        {
            string state = enabled ? "true" : "false";

            // controls whether roblox launches on startup
            storage["LaunchAtStartup"] = state;

            // keeps the client active in the tray
            storage["MinimizeToTray"] = state;
        }

        private static void ApplyTheme(JsonObject storage)
        {
            const string LOG_IDENT = "AppStorageManager::ApplyTheme";

            var theme = App.Settings.Prop.RobloxTheme;

            if (theme == RobloxTheme.Default)
                return;

            string value = theme == RobloxTheme.Dark ? "dark" : "light";

            storage["AuthenticatedTheme"] = value;

            // theme is stored per user, so we need to read the user id and update the map accordingly
            try
            {
                if (storage["UserId"] is not JsonValue idNode
                    || !idNode.TryGetValue(out string? userId)
                    || String.IsNullOrEmpty(userId))
                    return;

                JsonObject map = [];

                if (storage["DeviceLevelTheme"] is JsonValue mapNode
                    && mapNode.TryGetValue(out string? raw)
                    && !String.IsNullOrWhiteSpace(raw)
                    && JsonNode.Parse(raw) is JsonObject parsed)
                    map = parsed;

                map[userId] = value;

                // it's stored as a json string inside the json, not as a nested object
                storage["DeviceLevelTheme"] = map.ToJsonString(SerializerOptions);
            }
            catch (Exception ex)
            {
                App.Logger.Error($"{LOG_IDENT}: Failed to update the per-account theme cache");
                App.Logger.Error(ex);
            }
        }

        private static void Mutate(Action<JsonObject> mutate)
        {
            const string LOG_IDENT = "AppStorageManager::Mutate";

            string path = FileLocation;

            if (!File.Exists(path))
            {
                Create(path, mutate);
                return;
            }

            string? tempPath = null;

            try
            {
                path = new FileInfo(path).ResolveLinkTarget(true)?.FullName ?? path;

                string contents = File.ReadAllText(path);

                if (String.IsNullOrWhiteSpace(contents))
                {
                    App.Logger.Info($"{LOG_IDENT}: File is empty, leaving it alone");
                    return;
                }

                if (JsonNode.Parse(contents) is not JsonObject storage)
                {
                    App.Logger.Info($"{LOG_IDENT}: File is not a JSON object, leaving it alone");
                    return;
                }

                string original = storage.ToJsonString(SerializerOptions);

                mutate(storage);

                string output = storage.ToJsonString(SerializerOptions);

                if (output == original)
                {
                    App.Logger.Info($"{LOG_IDENT}: Already up to date");
                    return;
                }

                tempPath = path + ".exostrap-tmp";
                File.WriteAllText(tempPath, output, new UTF8Encoding(false));

                Filesystem.AssertReadOnly(path);
                File.Replace(tempPath, path, null);
                tempPath = null;

                App.Logger.Info($"{LOG_IDENT}: Saved successfully");
            }
            catch (Exception ex)
            {
                App.Logger.Error($"{LOG_IDENT}: Failed to patch {path}");
                App.Logger.Error(ex);
            }
            finally
            {
                if (tempPath is not null)
                {
                    try { File.Delete(tempPath); }
                    catch (Exception ex) { App.Logger.Error(ex); }
                }
            }
        }

        private static void Create(string path, Action<JsonObject> mutate)
        {
            const string LOG_IDENT = "AppStorageManager::Create";

            try
            {
                var storage = new JsonObject();

                mutate(storage);

                Directory.CreateDirectory(Path.GetDirectoryName(path)!);
                File.WriteAllText(path, storage.ToJsonString(SerializerOptions), new UTF8Encoding(false));

                App.Logger.Info($"{LOG_IDENT}: Seeded {path}");
            }
            catch (Exception ex)
            {
                App.Logger.Error($"{LOG_IDENT}: Failed to seed {path}");
                App.Logger.Error(ex);
            }
        }
    }
}
