﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums.AppStoragePresets
{
    internal enum RobloxTheme
    {
        [EnumName(StaticName = "Default")]
        Default,
        [EnumName(StaticName = "Light")]
        Light,
        [EnumName(StaticName = "Dark")]
        Dark
    }
}
