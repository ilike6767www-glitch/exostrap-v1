﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums
{
    internal enum CursorType
    {
        [EnumSort(Order = 1)]
        [EnumName(FromTranslation = "Common.Default")]
        Default,

        [EnumSort(Order = 2)]
        BlackAndWhiteDot,

        [EnumSort(Order = 3)]
        PurpleCross,

        [EnumSort(Order = 4)]
        From2013,

        [EnumSort(Order = 5)]
        From2006
    }
}