﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums.Messagebox
{
    internal enum MessageBoxImage
    {
        None,
        Error,
        Information,
        Question,
        Warning
    }
}
