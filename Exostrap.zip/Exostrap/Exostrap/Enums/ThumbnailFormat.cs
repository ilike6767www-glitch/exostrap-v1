﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums
{
    // Add the rest of the formats if im missing some
    internal enum ThumbnailFormat
    {
        Png,
        Jpeg
    }
}
