﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums
{
    internal enum TrayDoubleClickAction
    {
        [EnumName(FromTranslation = "Enums.TrayDoubleClickAction.ServerInfo")]
        ServerInfo,

        [EnumName(FromTranslation = "Enums.TrayDoubleClickAction.GameHistory")]
        GameHistory,

        [EnumName(FromTranslation = "Enums.TrayDoubleClickAction.None")]
        None
    }
}