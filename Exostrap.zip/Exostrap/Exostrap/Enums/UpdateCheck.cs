﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums
{
    internal enum UpdateCheck
    {
        Disabled,
        Stable,
        Test,
        Both
    }
}