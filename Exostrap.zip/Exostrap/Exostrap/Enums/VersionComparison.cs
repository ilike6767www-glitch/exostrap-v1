﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Enums
{
    internal enum VersionComparison
    {
        LessThan = -1,
        Equal = 0,
        GreaterThan = 1
    }
}
