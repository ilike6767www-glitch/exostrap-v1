﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Exceptions
{
    internal class AssertionException : Exception
    {
        public AssertionException() : base(
            $"This is very likely just an off-chance error. Please report this first, and then start {App.ProjectName} again.")
        {
        }

        public AssertionException(string message) : base(
            $"{message}\n\nThis is very likely just an off-chance error. Please report this first, and then start {App.ProjectName} again.")
        {
        }

        public AssertionException(string message, Exception innerException) : base(
            $"{message}\n\nThis is very likely just an off-chance error. Please report this first, and then start {App.ProjectName} again.",
            innerException)
        {
        }
    }
}