﻿using Exostrap.Enums.AppStoragePresets;

namespace Exostrap.Extensions;

internal class RobloxThemeEx
{
    public static IReadOnlyCollection<RobloxTheme> Selections =>
    [
        RobloxTheme.Default,
        RobloxTheme.Light,
        RobloxTheme.Dark
    ];
}
