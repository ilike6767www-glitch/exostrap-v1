﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

global using System;
global using System.Collections.Generic;
global using System.Diagnostics;
global using System.Globalization;
global using System.IO;
global using System.Text;
global using System.Text.Json;
global using System.Text.Json.Serialization;
global using System.Text.RegularExpressions;
global using System.Linq;
global using System.Net;
global using System.Net.Http;
global using System.Threading;
global using System.Threading.Tasks;

global using Exostrap.Enums;
global using Exostrap.Enums.Messagebox;
global using Exostrap.Enums.BootstrapperDialogs;
global using Exostrap.Exceptions;
global using Exostrap.Extensions;
global using Exostrap.Models;
global using Exostrap.Models.APIs;
global using Exostrap.Models.APIs.Config;
global using Exostrap.Models.APIs.GitHub;
global using Exostrap.Models.APIs.Roblox;
global using Exostrap.Models.APIs.RoValra;
global using Exostrap.Models.APIs.WebView2;
global using Exostrap.Models.Attributes;
global using Exostrap.Models.BloxstrapRPC;
global using Exostrap.Models.Entities;
global using Exostrap.Models.ExostrapStudioRPC;
global using Exostrap.Models.Manifest;
global using Exostrap.Models.Persistable;
global using Exostrap.Models.SettingTasks;
global using Exostrap.Models.SettingTasks.Base;
global using Exostrap.Resources;
global using Exostrap.UI;
global using Exostrap.Utility;
