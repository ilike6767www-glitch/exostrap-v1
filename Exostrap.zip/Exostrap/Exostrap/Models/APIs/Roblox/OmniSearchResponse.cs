﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Models.APIs.Roblox;

internal class OmniSearchResponse
{
    [JsonPropertyName("searchResults")]
    public List<OmniSearchGroup>? SearchResults { get; set; }
}

internal class OmniSearchGroup
{
    [JsonPropertyName("contents")]
    public List<OmniSearchContent>? Contents { get; set; }
}