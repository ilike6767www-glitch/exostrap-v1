﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.Models.APIs.Roblox
{
    internal class UserPresenceResponse
    {
        [JsonPropertyName("userPresences")]
        public List<UserPresence> UserPresences { get; set; } = new();
    }
}
