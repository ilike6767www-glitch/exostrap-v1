﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Exostrap.UI.ViewModels;

namespace Exostrap.Models
{
    internal class ModConfig : NotifyPropertyChangedViewModel
    {
        private string _folderName = "";
        private int _priority;
        private ModTarget _target = ModTarget.Both;
        private bool _enabled = true;

        public string FolderName
        {
            get => _folderName;
            set
            {
                if (SetProperty(ref _folderName, value))
                    OnPropertyChanged(nameof(FileCount));
            }
        }

        public int Priority
        {
            get => _priority;
            set => SetProperty(ref _priority, value);
        }

        public ModTarget Target
        {
            get => _target;
            set => SetProperty(ref _target, value);
        }

        public bool Enabled
        {
            get => _enabled;
            set => SetProperty(ref _enabled, value);
        }

        public int FileCount => GetFileCount();

        [JsonIgnore]
        public string FileCountDisplay => $"{FileCount} {Strings.Common_Files}";
        [JsonIgnore]
        public string PriorityDisplay => $"{Strings.Common_Priority} {Priority}";

        private int GetFileCount()
        {
            if (string.IsNullOrEmpty(FolderName)) return 0;
            string path = Path.Combine(Paths.Modifications, FolderName);
            if (!Directory.Exists(path)) return 0;
            try
            {
                return Directory.GetFiles(path, "*", SearchOption.AllDirectories).Length;
            }
            catch
            {
                return 0;
            }
        }
    }
}