﻿using System.Text.Json.Nodes;

namespace Exostrap.Models
{
    internal sealed class ModGeneratorInfo
    {
        public string ExostrapVersion { get; set; } = "";
        public string RobloxVersion { get; set; } = "";
        public string RobloxVersionHash { get; set; } = "";
        public JsonNode? ColorsUsed { get; set; }
    }
}