// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace Exostrap.UI.AppThemes.ResourceDictionarys
{
    internal partial class Light : ResourceDictionary
    {
        public Light()
        {
            AvaloniaXamlLoader.Load(this);
        }
    }
}
