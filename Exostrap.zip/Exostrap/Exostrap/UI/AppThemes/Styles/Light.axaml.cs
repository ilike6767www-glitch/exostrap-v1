// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Markup.Xaml;
using Avalonia.Styling;

namespace Exostrap.UI.AppThemes.Styles
{
    internal partial class Light : Avalonia.Styling.Styles
    {
        public Light()
        {
            AvaloniaXamlLoader.Load(this);
        }
    }
}
