// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Controls;

namespace Exostrap.UI.Elements.About.Pages;

internal partial class LicensesPage : UserControl
{
    public LicensesPage()
    {
        InitializeComponent();
    }
}