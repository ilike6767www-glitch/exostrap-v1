// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Exostrap.Integrations;
using Exostrap.UI.ViewModels.ContextMenu;

namespace Exostrap.UI.Elements.ContextMenu
{
    /// <summary>
    /// Interaction logic for ServerHistory.axaml
    /// </summary>
    internal partial class ServerHistory : Base.AvaloniaWindow
    {
        public ServerHistory()
        {
            InitializeComponent();
        }

        public ServerHistory(ActivityWatcher watcher) : this()
        {
            var viewModel = new ServerHistoryViewModel(watcher);

            viewModel.RequestCloseEvent += (_, _) => Close();

            DataContext = viewModel;
        }
    }
}