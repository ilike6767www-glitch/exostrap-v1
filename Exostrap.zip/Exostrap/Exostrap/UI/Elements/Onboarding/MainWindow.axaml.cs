// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Exostrap.UI.Elements.Base;
using Exostrap.UI.Elements.Onboarding.Pages;
using Exostrap.UI.Utility;
using Exostrap.UI.ViewModels.Onboarding;
using Exostrap.Utility;

namespace Exostrap.UI.Elements.Onboarding
{
    internal partial class MainWindow : AvaloniaWindow
    {
        public static MainWindow? Instance { get; private set; }
        internal readonly MainWindowViewModel _viewModel = new();
        private Type _currentPage = typeof(Page1);
        private bool _isInitialLoad = true;

        private readonly List<Type> _pages =
        [
            typeof(Page1),
            typeof(Page2),
            typeof(Page3),
            typeof(Page4),
            typeof(Page5),
            typeof(Page6),
            typeof(Page7)
        ];

        public Func<Task<bool>>? NextPageCallback;
        public NextAction CloseAction = NextAction.Terminate;
        public bool Finished => _currentPage == _pages.Last();

        public MainWindow()
        {
            Instance = this;
            DataContext = _viewModel;
            InitializeComponent();

            RootNavigation.PageCount = _pages.Count;

            _viewModel.PageRequest += (_, type) =>
            {
                if (type == "next")
                    NextPage();
                else if (type == "back")
                    BackPage();
            };

            Navigate(typeof(Page1));
            App.Logger.Debug("Initializing onboarding window");
        }

        async void NextPage()
        {
            if (NextPageCallback is not null && !await NextPageCallback())
                return;

            if (_currentPage == _pages.Last())
            {
                Close();
                return;
            }

            App.Settings.Save();
            var nextPageIndex = _pages.IndexOf(_currentPage) + 1;
            var page = _pages[nextPageIndex];
            Navigate(page);
        }

        void BackPage()
        {
            if (_currentPage == _pages.First())
                return;

            var prevPageIndex = _pages.IndexOf(_currentPage) - 1;
            var page = _pages[prevPageIndex];
            Navigate(page);
        }

        public void SetNextButtonText(string text) => _viewModel.SetNextButtonText(text);

        #region Navigation methods

        public bool Navigate(Type pageType)
        {
            int currentIndex = _pages.IndexOf(_currentPage);
            int newIndex = _pages.IndexOf(pageType);
            bool goingForward = newIndex > currentIndex;

            if (!_isInitialLoad)
            {
                RootFrame.PageTransition = new FluentSlideTransition
                {
                    Direction = goingForward ? SlideDirection.Right : SlideDirection.Left,
                    HorizontalOffset = 150,
                    Duration = TimeSpan.FromMilliseconds(300)
                };
            }
            else
            {
                RootFrame.PageTransition = null;
                _isInitialLoad = false;
            }

            _currentPage = pageType;
            NextPageCallback = null;

            var pageInstance = CreatePage(pageType);
            RootFrame.Content = pageInstance;

            var index = _pages.IndexOf(pageType);
            if (index >= 0)
                RootNavigation.CurrentIndex = index;

            if (_currentPage == _pages.Last())
                SetNextButtonText(Strings.Common_Finish);
            else
                SetNextButtonText(Strings.Common_Next);

            _viewModel.BackButtonEnabled = _currentPage != _pages.First();

            return true;
        }

        private static object CreatePage(Type pageType)
        {
            if (pageType == typeof(Page1)) return new Page1();
            if (pageType == typeof(Page2)) return new Page2();
            if (pageType == typeof(Page3)) return new Page3();
            if (pageType == typeof(Page4)) return new Page4();
            if (pageType == typeof(Page5)) return new Page5();
            if (pageType == typeof(Page6)) return new Page6();
            if (pageType == typeof(Page7)) return new Page7();
            return new Page1();
        }
        #endregion
    }
}