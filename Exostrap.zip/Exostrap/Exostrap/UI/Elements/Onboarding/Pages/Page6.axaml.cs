// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Controls;
using Exostrap.UI.ViewModels.Onboarding;

namespace Exostrap.UI.Elements.Onboarding.Pages
{
    internal partial class Page6 : UserControl
    {
        public Page6()
        {
            DataContext = new Page6ViewModel();
            InitializeComponent();
        }
    }
}
