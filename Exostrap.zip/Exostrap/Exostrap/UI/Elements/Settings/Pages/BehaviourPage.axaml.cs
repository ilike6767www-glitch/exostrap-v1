// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Controls;

namespace Exostrap.UI.Elements.Settings.Pages;

internal partial class BehaviourPage : UserControl
{
    public BehaviourPage()
    {
        InitializeComponent();

        App.ExoRPC?.SetPage("Bootstrapper");
    }
}
