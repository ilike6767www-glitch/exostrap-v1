﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

namespace Exostrap.UI.ViewModels.About
{
    internal class LicensesViewModel : NotifyPropertyChangedViewModel
    {
        //Why do we have this ?
    }
}