﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using CommunityToolkit.Mvvm.Input;
using Exostrap.Integrations;
using Avalonia.Media.Imaging;
using System.Windows.Input;

namespace Exostrap.UI.ViewModels.ContextMenu
{
    internal class ServerHistoryViewModel : NotifyPropertyChangedViewModel
    {
        private readonly ActivityWatcher _activityWatcher;

        public List<ActivityData>? GameHistory { get; private set; }

        public GenericTriState LoadState { get; private set; } = GenericTriState.Unknown;

        public string Error { get; private set; } = String.Empty;

        public ICommand CloseWindowCommand => new RelayCommand(RequestClose);
        public ICommand CleanOldHistoryCommand => new RelayCommand(CleanOldHistory);

        public EventHandler? RequestCloseEvent;

        public ServerHistoryViewModel(ActivityWatcher activityWatcher)
        {
            _activityWatcher = activityWatcher;

            _activityWatcher.OnGameLeave += (_, _) => LoadData();
            _activityWatcher.OnHistoryUpdated += (_, _) => LoadData();

            LoadData();
        }

        private async void LoadData()
        {
            LoadState = GenericTriState.Unknown;
            OnPropertyChanged(nameof(LoadState));

            try
            {
                await Task.Run(CleanOldEntries);

                var entriesNeedingDetails = _activityWatcher.History
                    .Where(x => x.UniverseId != 0 && x.UniverseDetails is null &&
                           x.TimeJoined > DateTime.Now.AddDays(-30))
                    .ToList();

                if (entriesNeedingDetails.Count > 0)
                {
                    var universeIds = entriesNeedingDetails
                        .Select(x => x.UniverseId)
                        .Distinct()
                        .ToList();

                    string universeIdsString = String.Join(',', universeIds);
                    await UniverseDetails.FetchBulk(universeIdsString);

                    foreach (var entry in entriesNeedingDetails)
                    {
                        entry.UniverseDetails = UniverseDetails.LoadFromCache(entry.UniverseId);
                    }
                }

                var processedHistory = ProcessAndConsolidateHistory(_activityWatcher.History);

                var thumbRequests = processedHistory.Select(r => new ThumbnailRequest
                {
                    Type = ThumbnailType.GameIcon,
                    TargetId = (ulong)r.UniverseId,
                    Size = ThumbnailSize.Large
                }).ToList();

                var fetchedUrls = await Thumbnails.GetThumbnailUrlsAsync(thumbRequests, CancellationToken.None);

                if (fetchedUrls != null)
                {
                    for (int i = 0; i < processedHistory.Count; i++)
                    {
                        if (i < fetchedUrls.Length && !string.IsNullOrEmpty(fetchedUrls[i]))
                        {
                            try
                            {
                                var response = await App.HttpClient.GetByteArrayAsync(new Uri(fetchedUrls[i]!));
                                using var ms = new MemoryStream(response);
                                processedHistory[i].ThumbnailBitmap = new Bitmap(ms);
                            }
                            catch (Exception imgEx)
                            {
                                App.Logger.Error($"Failed to load image: {imgEx.Message}");
                            }
                        }
                    }
                }

                GameHistory = processedHistory;

                if (GameHistory != null)
                {
                    foreach (var entry in GameHistory)
                    {
                        entry.OnDeleteRequested += OnActivityDeleteRequested;
                    }
                }

                OnPropertyChanged(nameof(GameHistory));
                LoadState = GenericTriState.Successful;
                OnPropertyChanged(nameof(LoadState));
            }
            catch (Exception ex)
            {
                App.Logger.Error("Unhandled exception: ", ex);

                Error = $"Failed to load game history: {ex.Message}";
                OnPropertyChanged(nameof(Error));

                LoadState = GenericTriState.Failed;
                OnPropertyChanged(nameof(LoadState));
            }
        }

        private static List<ActivityData> ProcessAndConsolidateHistory(List<ActivityData> history)
        {
            var cutoffDate = DateTime.Now.AddDays(-30);
            var consolidatedHistory = new List<ActivityData>();
            var processedRoots = new HashSet<string>();

            foreach (var entry in history
                .Where(x => x.TimeJoined > cutoffDate)
                .OrderByDescending(x => x.TimeJoined))
            {
                if (entry.ServerType == ServerType.Private || entry.ServerType == ServerType.Reserved)
                    continue;

                if (entry.RootActivity != null && !string.IsNullOrEmpty(entry.RootActivity.JobId))
                {
                    var rootId = entry.RootActivity.JobId;

                    if (!processedRoots.Contains(rootId))
                    {
                        var relatedSessions = history.Where(x =>
                            (x.RootActivity?.JobId == rootId || x.JobId == rootId) &&
                            x.TimeJoined > cutoffDate)
                            .OrderByDescending(x => x.TimeJoined)
                            .ToList();

                        if (relatedSessions.Count > 0)
                        {
                            var latestSession = relatedSessions.First();
                            var earliestSession = relatedSessions.Last();

                            var consolidatedEntry = new ActivityData
                            {
                                UniverseId = latestSession.UniverseId,
                                PlaceId = latestSession.PlaceId,
                                JobId = latestSession.JobId,
                                UserId = latestSession.UserId,
                                ServerType = latestSession.ServerType,
                                TimeJoined = earliestSession.RootActivity?.TimeJoined ?? earliestSession.TimeJoined,
                                TimeLeft = latestSession.TimeLeft,
                                UniverseDetails = latestSession.UniverseDetails,
                                IsTeleport = true,
                                RootJobId = rootId
                            };

                            consolidatedHistory.Add(consolidatedEntry);
                            processedRoots.Add(rootId);
                        }
                    }
                }
                else if (!string.IsNullOrEmpty(entry.JobId) && !processedRoots.Contains(entry.JobId))
                {
                    consolidatedHistory.Add(entry);
                    processedRoots.Add(entry.JobId);
                }
            }

            return [.. consolidatedHistory
                .GroupBy(x => x.UniverseId)
    .           SelectMany(g => g.OrderByDescending(x => x.TimeJoined).Take(3))
                .OrderByDescending(x => x.TimeJoined)];
        }

        private void CleanOldEntries()
        {
            try
            {
                var cutoffDate = DateTime.Now.AddDays(-30);
                int oldCount = _activityWatcher.History.Count;

                _activityWatcher.History.RemoveAll(x => x.TimeJoined < cutoffDate);

                int removedCount = oldCount - _activityWatcher.History.Count;

                if (removedCount > 0)
                {
                    App.Logger.Info($"Removed {removedCount} old history entries (older than {30} days)");

                    _activityWatcher.SaveGameHistory();
                }
            }
            catch (Exception ex)
            {
                App.Logger.Error("Unhandled exception: ", ex);
            }
        }

        private void CleanOldHistory()
        {
            CleanOldEntries();
            LoadData();
        }

        private void OnActivityDeleteRequested(object? sender, string jobId)
        {
            DeleteHistoryEntry(jobId);
        }

        public void DeleteHistoryEntry(string jobId)
        {
            try
            {
                int removedCount = _activityWatcher.History.RemoveAll(x => x.JobId == jobId);

                if (!string.IsNullOrEmpty(jobId))
                {
                    removedCount += _activityWatcher.History.RemoveAll(x =>
                        x.RootActivity?.JobId == jobId);
                }

                if (removedCount > 0)
                {
                    App.Logger.Info($"Removed {removedCount} history entries for job {jobId}");

                    _activityWatcher.SaveGameHistory();

                    LoadData();
                }
            }
            catch (Exception ex)
            {
                App.Logger.Error("Unhandled exception: ", ex);
            }
        }

        private void RequestClose() => RequestCloseEvent?.Invoke(this, EventArgs.Empty);
    }
}
