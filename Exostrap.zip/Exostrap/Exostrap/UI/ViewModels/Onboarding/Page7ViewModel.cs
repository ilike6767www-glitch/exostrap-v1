﻿// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using Exostrap.UI.Elements.Onboarding;

namespace Exostrap.UI.ViewModels.Onboarding
{
    internal class Page7ViewModel : NotifyPropertyChangedViewModel
    {
        public ICommand LaunchRobloxCommand { get; }
        public ICommand LaunchSettingsCommand { get; }

        public Page7ViewModel()
        {
            LaunchRobloxCommand = new RelayCommand(LaunchRoblox);
            LaunchSettingsCommand = new RelayCommand(LaunchSettings);
        }

        private void LaunchRoblox()
        {
            var mainWindow = MainWindow.Instance;
            if (mainWindow != null)
            {
                mainWindow.CloseAction = NextAction.LaunchRoblox;
                mainWindow.Close();
            }
        }

        private void LaunchSettings()
        {
            var mainWindow = MainWindow.Instance;
            if (mainWindow != null)
            {
                mainWindow.CloseAction = NextAction.LaunchSettings;
                mainWindow.Close();
            }
        }
    }
}
