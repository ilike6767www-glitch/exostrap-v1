// SPDX-FileCopyrightText: 2026 Froststrap
//
// SPDX-License-Identifier: MPL-2.0

using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Platform.Storage;
using CommunityToolkit.Mvvm.Input;
using CommunityToolkit.Mvvm.Messaging;
using Exostrap.UI.Elements.Base;
using Exostrap.UI.Elements.Dialogs;
using Exostrap.UI.Elements.Editor;
using ICSharpCode.SharpZipLib.Zip;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace Exostrap.UI.ViewModels.Settings
{
    internal partial class AppearanceViewModel : NotifyPropertyChangedViewModel
    {
        private static readonly string[] _zipFilter = ["*.zip"];
        private static readonly string[] JsonPatterns = ["*.json"];
        private static readonly JsonSerializerOptions SerializationOptions = new() { WriteIndented = true };
        private CustomThemeCycleSelectionWrapper? _selectedThemeWrapper;

        public ICommand PreviewBootstrapperCommand => new RelayCommand(PreviewBootstrapper);
        public IAsyncRelayCommand BrowseCustomIconLocationCommand => new AsyncRelayCommand<Control>(async c => await BrowseCustomIconLocation(c));
        public IAsyncRelayCommand BrowseCustomRobloxIconLocationCommand => new AsyncRelayCommand<Control>(async c => await BrowseCustomRobloxIconLocation(c));

        public ICommand AddCustomThemeCommand => new RelayCommand<Control>(async c => await AddCustomTheme(c));
        public ICommand EditCustomThemeCommand => new RelayCommand<Control>(async c => await EditCustomTheme(c));
        public ICommand ExportCustomThemeCommand => new RelayCommand<Control>(async c => await ExportCustomTheme(c));
        public IAsyncRelayCommand DeleteCustomThemeCommand => new AsyncRelayCommand(() => Task.Run(DeleteCustomTheme));
        public IAsyncRelayCommand RenameCustomThemeCommand => new AsyncRelayCommand(() => Task.Run(RenameCustomTheme));

        private async void PreviewBootstrapper()
        {
            App.ExoRPC?.SetDialog("Preview Launcher");

            IBootstrapperDialog dialog = await App.Settings.Prop.BootstrapperStyle.GetNew();

            dialog.Message = App.Settings.Prop.BootstrapperStyle == BootstrapperStyle.ByfronDialog
                ? Strings.Bootstrapper_StylePreview_ImageCancel
                : Strings.Bootstrapper_StylePreview_TextCancel;

            dialog.CancelEnabled = true;
            dialog.ShowBootstrapper();

            App.ExoRPC?.ClearDialog();
        }

        private async Task BrowseCustomIconLocation(Control? control)
        {
            if (control is null) return;

            var topLevel = TopLevel.GetTopLevel(control);
            if (topLevel is not Window parentWindow) return;

            var storageProvider = parentWindow.StorageProvider;

            var files = await storageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Select Icon File",
                AllowMultiple = false,
                FileTypeFilter = [new FilePickerFileType("Images") { Patterns = ["*.ico", "*.png", "*.jpg", "*.jpeg", "*.bmp"] }]
            });

            if (files.Count > 0)
            {
                CustomIconLocation = files[0].Path.LocalPath;
                OnPropertyChanged(nameof(CustomIconLocation));
            }
        }

        private async Task BrowseCustomRobloxIconLocation(Control? control)
        {
            if (control is null) return;

            var topLevel = TopLevel.GetTopLevel(control);
            if (topLevel is not Window parentWindow) return;

            var storageProvider = parentWindow.StorageProvider;

            var files = await storageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Select Roblox Icon File",
                AllowMultiple = false,
                FileTypeFilter = [new FilePickerFileType("Icons") { Patterns = ["*.ico"] }]
            });

            if (files.Count > 0)
            {
                CustomRobloxIconLocation = files[0].Path.LocalPath;
                OnPropertyChanged(nameof(CustomRobloxIconLocation));
            }
        }

        public static List<string> Languages => Locale.GetLanguages();

        public string SelectedLanguage
        {
            get
            {
                string identifier = App.Settings.Prop.Locale;
                if (identifier == "nil")
                    return Strings.Common_SystemDefault;

                return Locale.SupportedLocales.TryGetValue(identifier, out var value)
                    ? value
                    : Strings.Common_SystemDefault;
            }
            set
            {
                string? identifier = Locale.SupportedLocales.FirstOrDefault(x => x.Value == value).Key;

                if (identifier == null && value == Strings.Common_SystemDefault)
                    identifier = "nil";

                identifier ??= "nil";

                if (App.Settings.Prop.Locale != identifier)
                {
                    App.Settings.Prop.Locale = identifier;
                    OnPropertyChanged(nameof(SelectedLanguage));

                    Locale.Set(identifier);
                }
            }
        }

        public ObservableCollection<BootstrapperIconEntry> Icons { get; set; } = [];

        public BootstrapperIcon Icon
        {
            get => App.Settings.Prop.BootstrapperIcon;
            set
            {
                App.Settings.Prop.BootstrapperIcon = value;
                OnPropertyChanged(nameof(IsCustomIconSelected));
            }
        }

        public static bool IsCustomIconSelected => App.Settings.Prop.BootstrapperIcon == BootstrapperIcon.IconCustom;

        public ObservableCollection<RobloxIconEntry> RobloxIcons { get; set; } = [];

        public RobloxIcon RobloxIcon
        {
            get => App.Settings.Prop.RobloxIcon;
            set
            {
                App.Settings.Prop.RobloxIcon = value;
                OnPropertyChanged(nameof(IsCustomRobloxIconSelected));
            }
        }

        public static bool IsCustomRobloxIconSelected => App.Settings.Prop.RobloxIcon == RobloxIcon.IconCustom;

        public static bool DisableAnimations
        {
            get => App.Settings.Prop.DisableAnimations;
            set
            {
                App.Settings.Prop.DisableAnimations = value;
                App.Settings.Save();
                if (value)
                    App.ApplyAnimationSettings();
                else
                    App.RemoveAnimationSettings();
            }
        }

        public static IEnumerable<WindowsBackdrops> BackdropOptions => Enum.GetValues<WindowsBackdrops>().Where(IsBackdropSupported);

        public WindowsBackdrops SelectedBackdrop
        {
            get => App.Settings.Prop.SelectedBackdrop;
            set
            {
                var newValue = IsBackdropSupported(value) ? value : WindowsBackdrops.None;
                if (App.Settings.Prop.SelectedBackdrop != newValue)
                {
                    App.Settings.Prop.SelectedBackdrop = newValue;
                    OnPropertyChanged(nameof(SelectedBackdrop));
                    AvaloniaWindow.UpdateBackdropForAllWindows();
                }
            }
        }

        private static bool IsBackdropSupported(WindowsBackdrops backdrop)
        {
            if (!OperatingSystem.IsWindows())
                return backdrop == WindowsBackdrops.None;

            return backdrop switch
            {
                WindowsBackdrops.Mica => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 22000),
                WindowsBackdrops.Acrylic => OperatingSystem.IsWindowsVersionAtLeast(10, 0, 17763),
                _ => true
            };
        }

        public static string Title
        {
            get => App.Settings.Prop.BootstrapperTitle;
            set => App.Settings.Prop.BootstrapperTitle = value;
        }

        public static bool ShowInfo
        {
            get => App.Settings.Prop.BootstrapperShowInfo;
            set => App.Settings.Prop.BootstrapperShowInfo = value;
        }

        public string CustomIconLocation
        {
            get => App.Settings.Prop.BootstrapperIconCustomLocation;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    if (App.Settings.Prop.BootstrapperIcon == BootstrapperIcon.IconCustom)
                        App.Settings.Prop.BootstrapperIcon = BootstrapperIcon.IconExostrap;
                }
                else
                {
                    App.Settings.Prop.BootstrapperIcon = BootstrapperIcon.IconCustom;
                }

                App.Settings.Prop.BootstrapperIconCustomLocation = value;
                BootstrapperIconEx.InvalidateCustomIcon();

                var customEntry = Icons.FirstOrDefault(e => e.IconType == BootstrapperIcon.IconCustom);
                customEntry?.RefreshImage();

                OnPropertyChanged(nameof(Icon));
                OnPropertyChanged(nameof(Icons));

                if (!App.Settings.Prop.EnableActivityTracking && App.Settings.Prop.EnableWindowManipulation)
                {
                    App.Settings.Prop.EnableWindowManipulation = true;
                    WindowManipulationEnabled = false;
                }
            }
        }

        public bool WindowManipulationEnabled
        {
            get => ActivityTrackingEnabled && App.Settings.Prop.EnableWindowManipulation;
            set
            {
                if (value && !ActivityTrackingEnabled)
                    return;

                if (App.Settings.Prop.EnableWindowManipulation == value)
                    return;

                App.Settings.Prop.EnableWindowManipulation = value;

                if (!value)
                {
                    App.Settings.Prop.RobloxTitle = "Roblox";
                    App.Settings.Prop.RobloxIcon = RobloxIcon.IconDefault;
                    App.Settings.Prop.RobloxIconCustomLocation = "";
                    App.Settings.Prop.AutoChangeTitle = false;
                    App.Settings.Prop.AutoChangeTitleWithPlayerCount = false;
                    App.Settings.Prop.AutoChangeIcon = false;

                    OnPropertyChanged(nameof(WindowTitle));
                    OnPropertyChanged(nameof(RobloxIcon));
                    OnPropertyChanged(nameof(CustomRobloxIconLocation));
                    OnPropertyChanged(nameof(IsCustomRobloxIconSelected));
                    OnPropertyChanged(nameof(AutoChangeTitle));
                    OnPropertyChanged(nameof(AutoChangeTitlePlayerCounter));
                    OnPropertyChanged(nameof(AutoChangeIcon));
                }

                OnPropertyChanged(nameof(WindowManipulationEnabled));
            }
        }

        public bool ActivityTrackingEnabled
        {
            get => App.Settings.Prop.EnableActivityTracking;
            set
            {
                if (App.Settings.Prop.EnableActivityTracking == value)
                    return;

                App.Settings.Prop.EnableActivityTracking = value;
                OnPropertyChanged(nameof(ActivityTrackingEnabled));

                if (!value)
                    WindowManipulationEnabled = false;
            }
        }

        public string CustomRobloxIconLocation
        {
            get => App.Settings.Prop.RobloxIconCustomLocation;
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    if (App.Settings.Prop.RobloxIcon == RobloxIcon.IconCustom)
                        App.Settings.Prop.RobloxIcon = RobloxIcon.IconDefault;
                }
                else
                {
                    App.Settings.Prop.RobloxIcon = RobloxIcon.IconCustom;
                }

                App.Settings.Prop.RobloxIconCustomLocation = value;
                RobloxIconEx.InvalidateCustomIcon();

                var customEntry = RobloxIcons.FirstOrDefault(e => e.IconType == RobloxIcon.IconCustom);
                customEntry?.RefreshImage();

                OnPropertyChanged(nameof(RobloxIcon));
                OnPropertyChanged(nameof(RobloxIcons));
            }
        }

        public string WindowTitle
        {
            get => App.Settings.Prop.RobloxTitle;
            set
            {
                App.Settings.Prop.RobloxTitle = value;
                OnPropertyChanged(nameof(WindowTitle));
            }
        }

        public AppearanceViewModel()
        {
            foreach (var entry in BootstrapperIconEx.Selections)
                Icons.Add(new() { IconType = entry });

            foreach (var entry in RobloxIconEx.Selections)
                RobloxIcons.Add(new() { IconType = entry });

            PopulateCustomThemes();
            InitializeGradientStops();
        }

        public bool AutoChangeTitle
        {
            get => App.Settings.Prop.AutoChangeTitle;
            set
            {
                App.Settings.Prop.AutoChangeTitle = value;

                if (!value)
                {
                    AutoChangeTitlePlayerCounter = false;
                    OnPropertyChanged(nameof(AutoChangeTitlePlayerCounter));
                }

                OnPropertyChanged(nameof(AutoChangeTitle));
            }
        }

        public bool AutoChangeTitlePlayerCounter
        {
            get => App.Settings.Prop.AutoChangeTitleWithPlayerCount;
            set
            {
                App.Settings.Prop.AutoChangeTitleWithPlayerCount = value;
                OnPropertyChanged(nameof(AutoChangeTitlePlayerCounter));
            }
        }

        public bool AutoChangeIcon
        {
            get => App.Settings.Prop.AutoChangeIcon;
            set
            {
                App.Settings.Prop.AutoChangeIcon = value;
                OnPropertyChanged(nameof(AutoChangeIcon));
            }
        }

        public IEnumerable<BootstrapperStyle> Dialogs { get; } = BootstrapperStyleEx.Selections;

        public BootstrapperStyle Dialog
        {
            get => App.Settings.Prop.BootstrapperStyle;
            set
            {
                App.Settings.Prop.BootstrapperStyle = value;
                OnPropertyChanged(nameof(CustomThemesExpanded));
            }
        }

        public static bool CustomThemesExpanded => App.Settings.Prop.BootstrapperStyle == BootstrapperStyle.CustomDialog;

        public bool IsThemeCyclingEnabled
        {
            get => App.Settings.Prop.CycleEnabled;
            set
            {
                App.Settings.Prop.CycleEnabled = value;
                OnPropertyChanged(nameof(IsThemeCyclingEnabled));
            }
        }

        public static IEnumerable<CycleFrequency> CycleFrequencies => Enum.GetValues<CycleFrequency>();

        public CycleFrequency SelectedCycleFrequency
        {
            get => App.Settings.Prop.CycleFrequency;
            set
            {
                App.Settings.Prop.CycleFrequency = value;
                OnPropertyChanged(nameof(SelectedCycleFrequency));
                OnPropertyChanged(nameof(IsIntervalValueVisible));
            }
        }

        public int CycleIntervalValue
        {
            get => App.Settings.Prop.CycleIntervalValue;
            set
            {
                App.Settings.Prop.CycleIntervalValue = value;
                OnPropertyChanged(nameof(CycleIntervalValue));
            }
        }

        public bool IsIntervalValueVisible => SelectedCycleFrequency != CycleFrequency.EveryLaunch;

        public ObservableCollection<CustomThemeCycleSelectionWrapper> CustomThemeSelections { get; set; } = [];

        public void InitializeCustomThemeSelections()
        {
            foreach (var w in CustomThemeSelections)
                w.PropertyChanged -= OnCycleSelectionPropertyChanged;

            CustomThemeSelections.Clear();
            var savedList = App.Settings.Prop.CycleEnabledCustomThemes;

            foreach (var themeName in CustomThemes)
            {
                var selection = new CustomThemeCycleSelectionWrapper
                {
                    ThemeName = themeName,
                    IsSelected = savedList.Contains(themeName)
                };
                selection.PropertyChanged += OnCycleSelectionPropertyChanged;
                CustomThemeSelections.Add(selection);
            }
        }

        public CustomThemeCycleSelectionWrapper? SelectedThemeWrapper
        {
            get => _selectedThemeWrapper;
            set
            {
                if (_selectedThemeWrapper != value)
                {
                    _selectedThemeWrapper = value;
                    OnPropertyChanged();
                    SelectedCustomTheme = value?.ThemeName;
                }
            }
        }

        private void OnCycleSelectionPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (sender is CustomThemeCycleSelectionWrapper wrapper && e.PropertyName == nameof(wrapper.IsSelected))
            {
                var savedList = App.Settings.Prop.CycleEnabledCustomThemes;
                if (wrapper.IsSelected)
                {
                    if (!savedList.Contains(wrapper.ThemeName))
                        savedList.Add(wrapper.ThemeName);
                }
                else
                {
                    savedList.Remove(wrapper.ThemeName);
                }
            }
        }

        private static void DeleteCustomThemeStructure(string name)
        {
            string dir = Path.Combine(Paths.CustomThemes, name);
            if (Directory.Exists(dir))
                Directory.Delete(dir, true);
        }

        private static void RenameCustomThemeStructure(string oldName, string newName)
        {
            string oldDir = Path.Combine(Paths.CustomThemes, oldName);
            string newDir = Path.Combine(Paths.CustomThemes, newName);
            Directory.Move(oldDir, newDir);
        }

        private async Task AddCustomTheme(Control? control)
        {
            var topLevel = TopLevel.GetTopLevel(control) ??
                           (Avalonia.Application.Current?.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime)?.MainWindow;

            if (topLevel is not Window parentWindow)
            {
                App.Logger.Info("No parent window found.");
                return;
            }

            App.ExoRPC?.SetDialog("Add Custom Launcher");

            var dialog = new AddCustomThemeDialog();
            await dialog.ShowDialog(parentWindow);

            App.ExoRPC?.ClearDialog();

            if (dialog.Created)
            {
                CustomThemes.Add(dialog.ThemeName);
                var wrapper = new CustomThemeCycleSelectionWrapper { ThemeName = dialog.ThemeName, IsSelected = false };
                wrapper.PropertyChanged += OnCycleSelectionPropertyChanged;
                CustomThemeSelections.Add(wrapper);

                SelectedThemeWrapper = wrapper;
                SelectedCustomThemeIndex = CustomThemes.IndexOf(dialog.ThemeName);
                OnPropertyChanged(nameof(SelectedCustomThemeIndex));

                if (dialog.OpenEditor)
                    await EditCustomTheme(control);
            }
        }

        private async Task EditCustomTheme(Control? control)
        {
            if (SelectedCustomTheme is null) return;

            var topLevel = TopLevel.GetTopLevel(control);
            if (topLevel is not Window parentWindow) return;

            App.ExoRPC?.SetDialog("Editing Custom Theme");
            using (var editor = new BootstrapperEditorWindow(SelectedCustomTheme))
            {
                await editor.ShowDialog(parentWindow);
            }
            App.ExoRPC?.ClearDialog();
        }

        private async Task ExportCustomTheme(Control? control)
        {
            if (SelectedCustomTheme is null) return;

            var topLevel = TopLevel.GetTopLevel(control);
            if (topLevel is not Window parentWindow) return;

            var file = await parentWindow.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Export Theme",
                SuggestedFileName = $"{SelectedCustomTheme}.zip",
                FileTypeChoices = [new FilePickerFileType("Zip Archive") { Patterns = _zipFilter }]
            });

            if (file is null) return;

            string themeDir = Path.Combine(Paths.CustomThemes, SelectedCustomTheme);

            await Task.Run(async () =>
            {
                using var outputStream = await file.OpenWriteAsync();
                using var zipStream = new ZipOutputStream(outputStream);
                zipStream.SetLevel(5);

                foreach (var filePath in Directory.EnumerateFiles(themeDir, "*.*", SearchOption.AllDirectories))
                {
                    string relativePath = Path.GetRelativePath(themeDir, filePath);
                    var entry = new ZipEntry(relativePath) { DateTime = DateTime.Now };

                    await zipStream.PutNextEntryAsync(entry);
                    using var fileStream = File.OpenRead(filePath);
                    await fileStream.CopyToAsync(zipStream);
                    zipStream.CloseEntry();
                }

                zipStream.Finish();
            });
            Exostrap.Utility.Threading.ShellExecute(file.Path.LocalPath, select: true);
        }

        private async void DeleteCustomTheme()
        {
            if (SelectedCustomTheme is null) return;

            var themeToDelete = SelectedCustomTheme;

            try
            {
                DeleteCustomThemeStructure(themeToDelete);
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Unhandled exception: {ex.Message}");
                await Frontend.ShowMessageBox(string.Format(CultureInfo.InvariantCulture, Strings.Menu_Appearance_CustomThemes_DeleteFailed, themeToDelete, ex.Message), MessageBoxImage.Error);
                return;
            }

            await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
            {
                var wrapperToDelete = CustomThemeSelections.FirstOrDefault(w => w.ThemeName == themeToDelete);

                App.Settings.Prop.CycleEnabledCustomThemes.Remove(themeToDelete);

                if (wrapperToDelete != null)
                {
                    wrapperToDelete.PropertyChanged -= OnCycleSelectionPropertyChanged;
                    CustomThemeSelections.Remove(wrapperToDelete);
                }

                int idx = CustomThemes.IndexOf(themeToDelete);
                if (idx >= 0) CustomThemes.RemoveAt(idx);

                if (CustomThemes.Count > 0)
                {
                    var newSelectedWrapper = CustomThemeSelections.LastOrDefault();
                    SelectedThemeWrapper = newSelectedWrapper;
                    SelectedCustomThemeIndex = CustomThemes.Count - 1;
                }
                else
                {
                    SelectedThemeWrapper = null;
                    SelectedCustomTheme = null;
                    SelectedCustomThemeIndex = -1;
                }

                OnPropertyChanged(nameof(IsCustomThemeSelected));
                OnPropertyChanged(nameof(SelectedCustomThemeIndex));
            });
        }

        private async void RenameCustomTheme()
        {
            if (SelectedCustomTheme is null || SelectedCustomTheme == SelectedCustomThemeName)
                return;

            if (string.IsNullOrEmpty(SelectedCustomThemeName))
            {
                await Frontend.ShowMessageBox(Strings.CustomTheme_Add_Errors_NameEmpty, MessageBoxImage.Error);
                return;
            }

            var validationResult = PathValidator.IsFileNameValid(SelectedCustomThemeName);
            if (validationResult != PathValidator.ValidationResult.Ok)
            {
                string errorString = validationResult switch
                {
                    PathValidator.ValidationResult.IllegalCharacter => Strings.CustomTheme_Add_Errors_NameIllegalCharacters,
                    PathValidator.ValidationResult.ReservedFileName => Strings.CustomTheme_Add_Errors_NameReserved,
                    _ => Strings.CustomTheme_Add_Errors_Unknown
                };
                await Frontend.ShowMessageBox(errorString, MessageBoxImage.Error);
                return;
            }

            string path = Path.Combine(Paths.CustomThemes, SelectedCustomThemeName, "Theme.xml");
            if (File.Exists(path))
            {
                await Frontend.ShowMessageBox(Strings.CustomTheme_Add_Errors_NameTaken, MessageBoxImage.Error);
                return;
            }

            try
            {
                RenameCustomThemeStructure(SelectedCustomTheme, SelectedCustomThemeName);
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Unhandled exception: {ex.Message}");
                await Frontend.ShowMessageBox("Rename failed", MessageBoxImage.Error);
                return;
            }

            string newName = SelectedCustomThemeName;
            string oldName = SelectedCustomTheme;

            await Avalonia.Threading.Dispatcher.UIThread.InvokeAsync(() =>
            {
                int idx = CustomThemes.IndexOf(oldName);
                if (idx >= 0) CustomThemes[idx] = newName;

                var wrapper = CustomThemeSelections.FirstOrDefault(w => w.ThemeName == oldName);
                if (wrapper != null)
                {
                    wrapper.ThemeName = newName;
                    if (App.Settings.Prop.CycleEnabledCustomThemes.Remove(oldName))
                    {
                        App.Settings.Prop.CycleEnabledCustomThemes.Add(newName);
                    }
                }

                SelectedThemeWrapper = wrapper;
                SelectedCustomTheme = newName;
                SelectedCustomThemeIndex = idx;

                OnPropertyChanged(nameof(SelectedCustomThemeIndex));
                OnPropertyChanged(nameof(SelectedCustomTheme));
                OnPropertyChanged(nameof(SelectedCustomThemeName));
            });
        }

        private void PopulateCustomThemes()
        {
            string? selected = App.Settings.Prop.SelectedCustomTheme;
            CustomThemes.Clear();

            if (!Directory.Exists(Paths.CustomThemes))
                Directory.CreateDirectory(Paths.CustomThemes);

            foreach (string directory in Directory.GetDirectories(Paths.CustomThemes))
            {
                if (!File.Exists(Path.Combine(directory, "Theme.xml")))
                    continue;
                CustomThemes.Add(Path.GetFileName(directory));
            }

            InitializeCustomThemeSelections();

            if (!string.IsNullOrEmpty(selected))
            {
                var wrapper = CustomThemeSelections.FirstOrDefault(w => w.ThemeName == selected);
                if (wrapper != null)
                {
                    SelectedThemeWrapper = wrapper;
                    SelectedCustomThemeIndex = CustomThemes.IndexOf(selected);
                    SelectedCustomThemeName = selected;
                    OnPropertyChanged(nameof(SelectedCustomThemeIndex));
                    OnPropertyChanged(nameof(SelectedCustomThemeName));
                }
            }
        }

        public string? SelectedCustomTheme
        {
            get => App.Settings.Prop.SelectedCustomTheme;
            set
            {
                if (App.Settings.Prop.SelectedCustomTheme != value)
                {
                    App.Settings.Prop.SelectedCustomTheme = value;
                    SelectedCustomThemeName = value ?? string.Empty;

                    if (value != null)
                        SelectedThemeWrapper = CustomThemeSelections.FirstOrDefault(w => w.ThemeName == value);
                    else
                        SelectedThemeWrapper = null;

                    if (value != null && App.Settings.Prop.CycleEnabledCustomThemes.Contains(value))
                    {
                        App.Settings.Prop.CycleCurrentIndex = App.Settings.Prop.CycleEnabledCustomThemes.IndexOf(value);
                    }

                    OnPropertyChanged(nameof(SelectedCustomTheme));
                    OnPropertyChanged(nameof(SelectedCustomThemeName));
                    OnPropertyChanged(nameof(IsCustomThemeSelected));
                }
            }
        }

        public string SelectedCustomThemeName { get; set; } = "";
        public int SelectedCustomThemeIndex { get; set; }
        public ObservableCollection<string> CustomThemes { get; set; } = [];
        public bool IsCustomThemeSelected => SelectedCustomTheme is not null;

        #region Custom App Themes
        public IEnumerable<Theme> Themes { get; } = Enum.GetValues<Theme>();

        public Theme Theme
        {
            get => App.Settings.Prop.Theme;
            set
            {
                App.Settings.Prop.Theme = value;
                OnPropertyChanged(nameof(Theme));
                OnPropertyChanged(nameof(CustomThemeExpanded));
                ApplyThemeUpdate();
            }
        }

        public static bool CustomThemeExpanded => App.Settings.Prop.Theme == Theme.Custom;

        public IEnumerable<BackgroundMode> BackgroundTypes { get; } = Enum.GetValues<BackgroundMode>();
        public IEnumerable<BackgroundStretch> BackgroundStretches { get; } = Enum.GetValues<BackgroundStretch>();

        public BackgroundMode BackgroundType
        {
            get => App.Settings.Prop.BackgroundType;
            set
            {
                App.Settings.Prop.BackgroundType = value;
                OnPropertyChanged(nameof(BackgroundType));
                OnPropertyChanged(nameof(IsGradientMode));
                OnPropertyChanged(nameof(IsImageMode));
                ApplyThemeUpdate();
            }
        }

        public BackgroundStretch BackgroundStretch
        {
            get => App.Settings.Prop.BackgroundStretch;
            set
            {
                App.Settings.Prop.BackgroundStretch = value;
                OnPropertyChanged(nameof(BackgroundStretch));
                ApplyThemeUpdate();
            }
        }

        public double BackgroundOpacity
        {
            get => App.Settings.Prop.BackgroundOpacity;
            set
            {
                App.Settings.Prop.BackgroundOpacity = value;
                OnPropertyChanged(nameof(BackgroundOpacity));
                ApplyThemeUpdate();
            }
        }

        public string BackgroundImagePath
        {
            get => App.Settings.Prop.BackgroundImagePath ?? string.Empty;
            set
            {
                App.Settings.Prop.BackgroundImagePath = value;
                OnPropertyChanged(nameof(BackgroundImagePath));
                ApplyThemeUpdate();
            }
        }

        public bool IsGradientMode => BackgroundType == BackgroundMode.Gradient;
        public bool IsImageMode => BackgroundType == BackgroundMode.Image;
        public double? GradientAngle
        {
            get => App.Settings.Prop.GradientAngle;
            set
            {
                if (!value.HasValue || value.Value < 0 || value.Value > 360)
                    return;

                if (App.Settings.Prop.GradientAngle == value)
                    return;

                App.Settings.Prop.GradientAngle = value.Value;
                OnPropertyChanged(nameof(GradientAngle));
                ApplyThemeUpdate();
            }
        }

        public ObservableCollection<GradientStops> GradientStops { get; } = [];

        private ICommand? _addGradientStopCommand;
        public ICommand AddGradientStopCommand => _addGradientStopCommand ??= new RelayCommand(async () => await AddGradientStop());

        private ICommand? _resetGradientCommand;
        public ICommand ResetGradientCommand => _resetGradientCommand ??= new RelayCommand(ResetGradient);

        private ICommand? _removeGradientStopCommand;
        public ICommand RemoveGradientStopCommand => _removeGradientStopCommand ??= new RelayCommand<GradientStops>(stop =>
        {
            if (stop != null)
                RemoveGradientStop(stop);
        });

        private ICommand? _exportGradientCommand;
        public ICommand ExportGradientCommand => _exportGradientCommand ??= new RelayCommand<TopLevel>(async topLevel =>
        {
            if (topLevel != null)
                await ExportGradient(topLevel);
        });

        private ICommand? _importGradientCommand;
        public ICommand ImportGradientCommand => _importGradientCommand ??= new RelayCommand<TopLevel>(async topLevel =>
        {
            if (topLevel != null)
                await ImportGradient(topLevel);
        });

        private ICommand? _selectImageCommand;
        public ICommand SelectImageCommand => _selectImageCommand ??= new RelayCommand<TopLevel>(async tl =>
        {
            if (tl == null) return;

            var files = await tl.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Select Background Image",
                FileTypeFilter = [FilePickerFileTypes.ImageAll],
                AllowMultiple = false
            });

            if (files.Count > 0)
            {
                BackgroundImagePath = files[0].Path.LocalPath;
            }
        });

        private ICommand? _clearImageCommand;
        public ICommand ClearImageCommand => _clearImageCommand ??= new RelayCommand(() =>
        {
            BackgroundImagePath = string.Empty;
        });

        private ICommand? _openColorPickerCommand;
        public ICommand OpenColorPickerCommand => _openColorPickerCommand ??= new RelayCommand<Control>(async control =>
        {
            if (control?.DataContext is not GradientStops stop) return;

            var topLevel = TopLevel.GetTopLevel(control);
            if (topLevel is not Window parentWindow) return;

            var dialog = new ColorPickerDialog(stop.Color);
            var result = await dialog.ShowDialog<string>(parentWindow);

            if (!string.IsNullOrWhiteSpace(result))
            {
                stop.Color = result;
            }
        });

        private void OnGradientStopPropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            ApplyThemeUpdate();
        }

        private async Task AddGradientStop()
        {
            GradientStops newStop = new() { Offset = 0.5, Color = "#000000" };
            newStop.PropertyChanged += OnGradientStopPropertyChanged;
            GradientStops.Add(newStop);
            ApplyThemeUpdate();
        }

        private void RemoveGradientStop(GradientStops stop)
        {
            if (stop == null) return;
            stop.PropertyChanged -= OnGradientStopPropertyChanged;
            GradientStops.Remove(stop);
            ApplyThemeUpdate();
        }

        private void ResetGradient()
        {
            List<GradientStops> defaultStops =
            [
                new() { Offset = 0.0, Color = "#8025304A" },
                new() { Offset = 0.5, Color = "#80272F48" },
                new() { Offset = 1.0, Color = "#80202C36" }
            ];

            foreach (var stop in GradientStops) stop.PropertyChanged -= OnGradientStopPropertyChanged;
            GradientStops.Clear();

            foreach (var stop in defaultStops)
            {
                stop.PropertyChanged += OnGradientStopPropertyChanged;
                GradientStops.Add(stop);
            }

            GradientAngle = 0;
            OnPropertyChanged(nameof(GradientAngle));

            ApplyThemeUpdate();
        }

        private async Task ExportGradient(TopLevel topLevel)
        {
            var file = await topLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Export Gradient",
                FileTypeChoices = [new FilePickerFileType("JSON Files") { Patterns = JsonPatterns }],
                SuggestedFileName = "Exostrap Gradient Background.json"
            });

            if (file == null) return;

            var data = new GradientExport
            {
                GradientStops = [.. GradientStops.Select(s => new Models.GradientStops { Offset = s.Offset, Color = s.Color })],
                GradientAngle = GradientAngle
            };

            using var stream = await file.OpenWriteAsync();
            await JsonHelper.SerializeAsync(stream, data, SerializationOptions);
        }

        private async Task ImportGradient(TopLevel topLevel)
        {
            var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Import Gradient",
                FileTypeFilter = [new FilePickerFileType("JSON Files") { Patterns = JsonPatterns }],
                AllowMultiple = false
            });

            if (files.Count == 0) return;
            var file = files[0];

            try
            {
                using var stream = await file.OpenReadAsync();
                using var document = await JsonDocument.ParseAsync(stream);
                var root = document.RootElement;

                foreach (var s in GradientStops) s.PropertyChanged -= OnGradientStopPropertyChanged;
                GradientStops.Clear();

                if (root.TryGetProperty(nameof(GradientStops), out var stopsElement))
                {
                    foreach (var stop in stopsElement.EnumerateArray())
                    {
                        GradientStops newStop = new()
                        {
                            Offset = stop.GetProperty("Offset").GetDouble(),
                            Color = stop.GetProperty("Color").GetString() ?? "#FFFFFF"
                        };
                        newStop.PropertyChanged += OnGradientStopPropertyChanged;
                        GradientStops.Add(newStop);
                    }
                }

                if (root.TryGetProperty(nameof(GradientAngle), out var angleElement))
                {
                    GradientAngle = angleElement.GetDouble();
                }

                ApplyThemeUpdate();
            }
            catch (Exception ex)
            {
                App.Logger.Error($"Unhandled exception: {ex.Message}");
            }
        }

        private void ApplyThemeUpdate()
        {
            App.Settings.Prop.CustomGradientStops = [.. GradientStops.Select(x => new GradientStops
            {
                Offset = x.Offset,
                Color = x.Color
            })];

            App.Settings.Prop.GradientAngle = GradientAngle;

            AvaloniaWindow.ApplyTheme();
        }

        private void InitializeGradientStops()
        {
            foreach (var s in GradientStops) s.PropertyChanged -= OnGradientStopPropertyChanged;
            GradientStops.Clear();

            var savedStops = App.Settings.Prop.CustomGradientStops;
            if (savedStops != null && savedStops.Count > 0)
            {
                foreach (var stop in savedStops)
                {
                    GradientStops newStop = new()
                    {
                        Offset = stop.Offset,
                        Color = stop.Color
                    };

                    newStop.PropertyChanged += OnGradientStopPropertyChanged;
                    GradientStops.Add(newStop);
                }
            }
            else if (App.Settings.Prop.Theme == Theme.Custom)
            {
                ResetGradient();
            }
        }
        #endregion
    }

    internal class CustomThemeCycleSelectionWrapper : NotifyPropertyChangedViewModel
    {
        private bool _isSelected;
        private string _themeName = string.Empty;

        public string ThemeName
        {
            get => _themeName;
            set
            {
                if (_themeName != value)
                {
                    _themeName = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                OnPropertyChanged();
            }
        }
    }
}
