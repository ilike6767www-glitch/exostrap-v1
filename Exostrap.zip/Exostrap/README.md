<h1 align="center">
    Exostrap
</h1>

<p align="center">
    Exostrap is a cross-platform Roblox bootstrapper focused on FastFlags, forked from
    <a href="https://github.com/Froststrap/Froststrap"><strong>Froststrap</strong></a>
    (itself derived from <a href="https://github.com/fishstrap/fishstrap">Fishstrap</a> and
    <a href="https://github.com/bloxstraplabs/bloxstrap">Bloxstrap</a>).
</p>

<p align="center">
    <img src="./.resources/exostrap.webp" height=200 alt="Exostrap logo"/>
</p>

> [!CAUTION]
> Only download Exostrap binaries from the official repository of whoever publishes your copy. Never run an
> "Exostrap" executable you can't trace back to its source.

---

## What it does

### FastFlags
- Edit Roblox FastFlags from a UI, with presets for rendering mode, MSAA, texture quality, FRM quality and more
- Automatic warning when you apply a FastFlag that is **not** in Roblox's FastFlag allowlist
- FastFlag profiles, import/export, and a "Clean List" action that removes flags outside the allowlist
- Allowlist data comes from a signed upstream config (see [CREDITS.md](./CREDITS.md))

### Launcher
- Switch Roblox update channels, block Roblox updates, or pin a version
- Customisable bootstrapper dialog, themes, and background (image, gradient, Aero/Acrylic/Mica)
- Game shortcuts, region selector, built-in account manager

### Integrations & mods
- Discord Rich Presence (Roblox player and Studio)
- Multi-mod system, community mods, and a generator for cursor / Shift Lock / emote wheel colours
- Import settings from Fishstrap and Bloxstrap

---

## Before you publish your own builds

Exostrap ships with publisher-specific settings **unset on purpose**, so it never updates itself from, or
impersonates, an account that isn't yours.

1. **GitHub account**: replace `YOUR-GITHUB-USERNAME` with yours:
   ```bash
   grep -rIl "YOUR-GITHUB-USERNAME" . | xargs sed -i 's/YOUR-GITHUB-USERNAME/<your-username>/g'
   ```
   The important occurrence is `App.ProjectOwner` in `Exostrap/App.axaml.cs`. Until it is set, the
   **self-updater is disabled** (`UpdaterManager.IsConfigured`).
2. **Releases**: the CI workflows publish Velopack packages to `<owner>/packages` and need a
   `PACKAGE_TOKEN` repository secret. The winget workflow stays off until you set the repository variable
   `ENABLE_WINGET=true`.
3. **Discord**: create an application at <https://discord.com/developers/applications>, add a Rich Presence
   art asset named `exostrap`, and set `App.DiscordApplicationId`. Until then the "Using Exostrap" presence
   is off.
4. **Community links**: the "Discord" buttons (launch menu, About page, onboarding) still point at
   Froststrap's server (`discord.gg/KdR9vpRcUN`), since Exostrap has none of its own. Swap in yours with
   `grep -rIl "discord.gg/KdR9vpRcUN" Exostrap | xargs sed -i 's#KdR9vpRcUN#<your-invite-code>#g'`.
5. **Submodules**: clone with `--recurse-submodules` (see [BUILDING.rst](./BUILDING.rst)); a ZIP download
   leaves `libs/` empty.

## Building

See [BUILDING.rst](./BUILDING.rst). In short: .NET 10 SDK, Rust (nightly), then `cargo xtask build`
or `cargo xtask publish`.

## Licensing and credits

Exostrap is released under [MPL-2.0](./LICENSE). It is built on the work of Froststrap, Fishstrap, Bloxstrap
and their contributors; see [CREDITS.md](./CREDITS.md). Exostrap is not affiliated with or endorsed by
Roblox Corporation. Modifying FastFlags is done at your own risk, so stick to flags on Roblox's allowlist.
