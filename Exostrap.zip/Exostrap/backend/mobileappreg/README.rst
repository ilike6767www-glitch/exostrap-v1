MobileAppReg
============

Simple module to force registration of URI's for Exostrap.

This is apart of the whole suite of backend related stuff for Exostrap to operate.
This is macOS only, In the C# Native -> FFI boundary there is no-op implementation.
