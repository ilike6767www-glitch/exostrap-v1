{
  lib,
  appimageTools,
  fetchurl,
  makeDesktopItem,
  version,
  sha256,
}:
let
  src = fetchurl {
    url = "https://github.com/YOUR-GITHUB-USERNAME/Exostrap/releases/download/v${version}/Exostrap-linux-x64.AppImage";
    inherit sha256;
  };

  appimageContents = appimageTools.extractType2 {
    inherit version src;
    pname = "exostrap";
  };

  desktopItem = makeDesktopItem {
    name = "exostrap";
    desktopName = "Exostrap";
    comment = "A cross-platform Roblox bootstrapper, focused on performance and customization.";
    exec = "exostrap %u";
    icon = "exostrap";
    categories = [ "Game" ];
    mimeTypes = [
      "x-scheme-handler/roblox"
      "x-scheme-handler/roblox-player"
      "x-scheme-handler/roblox-studio"
      "x-scheme-handler/roblox-studio-auth"
    ];
  };
in
appimageTools.wrapType2 {
  pname = "exostrap";
  inherit version src;

  extraPkgs =
    pkgs: with pkgs; [
      icu
      dbus
    ];

  # list values must end with ";". makeDesktopItem omits it.
  extraInstallCommands = ''
    install -Dm644 ${desktopItem}/share/applications/exostrap.desktop \
        $out/share/applications/exostrap.desktop

    sed -i -E '/^(Categories|MimeType)=/ s/([^;])$/\1;/' \
        $out/share/applications/exostrap.desktop

    install -Dm644 ${appimageContents}/usr/share/icons/hicolor/scalable/apps/Exostrap.png \
        $out/share/icons/hicolor/512x512/apps/exostrap.png
  '';

  meta = {
    description = "A cross-platform Roblox bootstrapper, focused on performance and customization.";
    homepage = "https://github.com/YOUR-GITHUB-USERNAME/Exostrap";
    license = lib.licenses.mpl20;
    platforms = [ "x86_64-linux" ];
  };
}
